let currentPage = 1;
let loading = false;
const postsPerPage = 3;
const postsContainer = document.getElementById('posts-box-container');

// Function to get user_id from localStorage
function getUserIdFromLocalStorage() {
    const userIdString = localStorage.getItem('user_id'); // Fetch user_id from localStorage
    return userIdString ? Number(userIdString) : null;
}

const userId = getUserIdFromLocalStorage();

document.addEventListener('DOMContentLoaded', function() {
    if (userId) {
        loadLikedPosts();
    } else {
        window.location.href = 'login.html';
    }
});

window.addEventListener('scroll', function() {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 800) {
        if (!loading) {
            loadLikedPosts();
        }
    }
});

function loadLikedPosts() {
    loading = true;
    document.querySelector('.loading').style.display = 'block';

    fetch(`https://campusarchive.com.ng/api/user_likes.php?page=${currentPage}&limit=${postsPerPage}&user_id=${userId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
            if (data.posts && data.posts.length > 0) {
                data.posts.forEach(post => {
                    postsContainer.innerHTML += renderPost(post);
                });
                currentPage++;
            } else {
                postsContainer.innerHTML += '<p>No more liked posts to display.</p>';
            }
            loading = false;
            document.querySelector('.loading').style.display = 'none';
        })
        .catch(error => {
            console.error('Error fetching liked posts:', error);
            document.querySelector('.loading').style.display = 'none';
            loading = false;
            if (error.message === 'User not logged in') {
                window.location.href = 'login.html';
            }
        });
}

function renderPost(post) {
    return `
        <div class="box">
            <div class="post-admin">
                <img src="https://campusarchive.com.ng/${post.adminImage}" alt="Admin Image" class="pimg" loading="lazy">
                <div>
                    <span class="profile-link" onclick="navigateToProfile('${post.adminName}')">${post.adminName}</span>
                    <div class="dat">${timeAgo(post.date)}</div>
                </div>
            </div>
            <a href="view_post.html?post_id=${post.id}" class="inline-btn" id="co">
                <div class="post-content" id="pco">${post.content}</div>
                ${post.image && post.image !== 'null.jpg' ? 
                    `<img src="uploaded_img/${post.image}" class="post-image" alt="" width="100%" height="auto" style="display: block; margin: 0 auto;">
                    <br>` : ''
                }
            </a>
            <div class="icons" id="icoo">
                <div><i class="fas fa-comment"></i><span>${post.comments}</span></div>
                <div onclick="copyUrl('${post.id}')"><i class="fas fa-share"></i></div>
                <div onclick="reportPost(${post.id})"><i class="fas fa-flag"></i></div>     
                <button type="button" class="like-btn liked" onclick="handleLike(${post.id}, this)">
                    <i class="fas fa-heart" style="color:var(--red);"></i>
                    <span>${post.likes}</span>
                </button>
            </div>
        </div>
    `;
}

function navigateToProfile(adminName) {
    window.location.href = `u.html?u=${encodeURIComponent(adminName)}`;
}

// Utility function for time ago
function timeAgo(dateString) {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);
    const intervals = {
        year: 31536000,
        month: 2592000,
        week: 604800,
        day: 86400,
        hour: 3600,
        minute: 60,
    };
    for (const [unit, value] of Object.entries(intervals)) {
        const interval = Math.floor(seconds / value);
        if (interval > 1) {
            return `${interval} ${unit}s ago`;
        }
    }
    return 'Just now';
}

It shows -3600 seconds 
