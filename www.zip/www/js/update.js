function getUserIdFromLocalStorage() {
    const userIdString = localStorage.getItem('user_id');
    return userIdString ? Number(userIdString) : null;
}

const userId = getUserIdFromLocalStorage();

function validateFileType(input) {
    const file = input.files[0];
    const allowedTypes = ['image/jpeg', 'image/png'];

    if (file && !allowedTypes.includes(file.type)) {
        Swal.fire({
            icon: 'warning',
            title: 'Invalid file type',
            text: 'Please select a valid image file (JPEG, PNG)',
            confirmButtonText: 'Okay'
        });
        input.value = ''; // Clear the selected file
    }
}

function handleFetchError(error) {
    console.error('Fetch error:', error);
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'An error occurred while communicating with the server. Please try again later.',
        confirmButtonText: 'Okay'
    });
}

document.addEventListener('DOMContentLoaded', function() {

    const userId = getUserIdFromLocalStorage();

    if (!userId) {
        Swal.fire({
            icon: 'warning',
            title: 'Login Required',
            text: 'You need to log in to update your profile.',
            confirmButtonText: 'Login'
        }).then(() => {
            window.location.href = 'login.html';
        });
        return;
    }

    // Fetch user data
    fetch(`https://campusarchive.com.ng/api/update.php?action=get_user&id=${userId}`)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
            if (data.error) throw new Error(data.error);
            document.getElementById('name').placeholder = data.name;
            document.getElementById('email').value = data.email;
        })
        .catch(handleFetchError);

    // Handle form submission
    document.getElementById('updateForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        formData.append('user_id', userId);

        fetch('https://campusarchive.com.ng/api/update.php?action=update_user', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
            if (data.error) throw new Error(data.error);
            Swal.fire({
                icon: 'success',
                title: 'Profile updated!',
            }).then(() => {
                setTimeout(function() {
                    location.reload(); // Refresh page after successful update
                }, 400);
            });
        })
        .catch(handleFetchError);
    });

    // Image preview feature with validation
    document.getElementById('imagee').addEventListener('change', function() {
        validateFileType(this);
        const imagePreview = document.getElementById('image-preview');
        imagePreview.innerHTML = ''; // Clear previous previews

        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                const container = document.createElement('div');
                container.style.position = 'relative';
                container.style.display = 'inline-block';

                const img = document.createElement('img');
                img.src = event.target.result;
                img.style.width = '100px';
                img.style.height = '100px';
                img.style.marginTop = '15px';
                img.style.borderRadius = '50%';
                container.appendChild(img);

                const cancelButton = document.createElement('button');
                cancelButton.innerHTML = '&times;';
                cancelButton.style.position = 'absolute';
                cancelButton.style.top = '15px';
                cancelButton.style.right = '0';
                cancelButton.style.background = 'red';
                cancelButton.style.color = 'white';
                cancelButton.style.border = 'none';
                cancelButton.style.borderRadius = '50%';
                cancelButton.style.width = '20px';
                cancelButton.style.height = '20px';
                cancelButton.style.cursor = 'pointer';

                cancelButton.addEventListener('click', function() {
                    imagePreview.innerHTML = '';
                    document.getElementById('imagee').value = ''; // Reset file input
                });

                container.appendChild(cancelButton);
                imagePreview.appendChild(container);
            }
            reader.readAsDataURL(file);
        }
    });
});
