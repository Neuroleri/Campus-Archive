// Function to get user ID from local storage
function getUserIdFromLocalStorage() {
    const userIdString = localStorage.getItem('user_id');
    return userIdString ? Number(userIdString) : null;
}
document.querySelector('.loading').style.display = 'none';
document.addEventListener('DOMContentLoaded', function() {
    const userId = getUserIdFromLocalStorage();

    // Check if user is logged in
    if (!userId) {
        Swal.fire({
            icon: 'warning',
            title: 'User not logged in',
            text: 'Please log in to continue.',
        }).then(() => {
            window.location.href = 'login.html'; // Redirect to login page if not logged in
        });
        return;
    }

    // Image preview feature
    document.getElementById('image').addEventListener('change', function() {
        const imagePreview = document.getElementById('image-preview');
        imagePreview.innerHTML = ''; // Clear previous previews

        const file = this.files[0];
        if (file) {
            const reader = new FileReader();

            reader.onload = function(event) {
                const container = document.createElement('div');
                container.style.position = 'relative';
                container.style.display = 'inline-block';
                container.style.maxWidth = '100%';

                const img = document.createElement('img');
                img.src = event.target.result;
                img.style.maxWidth = '100%';
                img.style.marginTop = '15px';
                img.style.borderRadius = '3px';
                container.appendChild(img);

                const cancelButton = document.createElement('button');
                cancelButton.innerHTML = '&times;';
                cancelButton.style.position = 'absolute';
                cancelButton.style.top = '20px';
                cancelButton.style.right = '5px';
                cancelButton.style.background = 'rgba(255, 0, 0, 0.7)';
                cancelButton.style.color = 'white';
                cancelButton.style.border = 'none';
                cancelButton.style.borderRadius = '50%';
                cancelButton.style.width = '25px';
                cancelButton.style.height = '25px';
                cancelButton.style.cursor = 'pointer';
                cancelButton.style.display = 'flex';
                cancelButton.style.justifyContent = 'center';
                cancelButton.style.alignItems = 'center';
                cancelButton.style.fontSize = '18px';
                cancelButton.style.padding = '0';

                cancelButton.addEventListener('click', function() {
                    imagePreview.innerHTML = '';
                    document.getElementById('image').value = ''; // Reset file input
                });

                container.appendChild(cancelButton);
                imagePreview.appendChild(container);
            }

            reader.readAsDataURL(file);
        }
    });

    // Publish button
    document.getElementById('publishBtn').addEventListener('click', function() {
        submitPost('active'); // Pass 'active' for published posts
    });

    // Draft button
    document.getElementById('draftBtn').addEventListener('click', function() {
        submitPost('deactive'); // Pass 'deactive' for drafts
    });

    // Submit post function
    function submitPost(status) {
        const form = document.getElementById('postForm');
        const formData = new FormData(form);

        formData.append('user_id', userId); // Append the user_id from local storage
        formData.append('status', status);  // Append the post status ('active' or 'deactive')

        const content = formData.get('content')?.trim(); // Trim any extra whitespace
        const imageFile = formData.get('image');

        // Check if both content and image are empty
        if (!content && (!imageFile || !imageFile.name)) {
            Swal.fire({
                icon: 'warning',
                title: 'Post Not Submitted',
                text: 'You need to say something or attach an image to make a post!',
            });
            return; // Stop submission if both are empty
        }

        fetch('https://campusarchive.com.ng/api/add.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
            if (data.success) {
                Swal.fire({
                    icon: 'success',
                    title: status === 'active' ? 'Post Published!' : 'Draft Saved!',
                    text: 'Your post has been successfully shared!',
                }).then(() => {
                    window.location.href = 'index.html'; // Redirect to index after successful post
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Post Failed',
                    text: data.message || 'Oops! Something went wrong while sharing your post.',
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An error occurred while trying to share your post. Please try again.',
            });
        });
    }
});
