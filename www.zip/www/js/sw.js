// sw.js (service worker)
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open('posts-cache-v1').then((cache) => {
            return cache.addAll([
                '/',
                '/index.html',
                '/style.css',
                '/script.js', // Include necessary assets
            ]);
        })
    );
});

self.addEventListener('fetch', (event) => {
    if (event.request.url.includes('/api/posts.php')) {
        event.respondWith(
            caches.match(event.request).then((response) => {
                return response || fetch(event.request).then((fetchResponse) => {
                    return caches.open('posts-cache-v1').then((cache) => {
                        cache.put(event.request, fetchResponse.clone());
                        return fetchResponse;
                    });
                });
            }).catch(() => {
                return caches.match('/offline.html'); // Fallback when offline
            })
        );
    }
});