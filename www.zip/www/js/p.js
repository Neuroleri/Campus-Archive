// Define global variables for pagination and containers
let currentPage = 1;
let loading = false;
const postsPerPage = 10;
const postsContainer = document.getElementById('posts-box-container');
const profileInfoContainer = document.getElementById('profile-info');

document.addEventListener('DOMContentLoaded', function() {
    // Load the user's profile and posts when the DOM is ready
    loadUserProfile();
    loadUserPosts();
});

// Function to get user ID from local storage
function getUserIdFromLocalStorage() {
    const userId = localStorage.getItem('user_id'); // Extract the user_id from local storage
    return userId ? Number(userId) : null; // Return user ID as a number or null if not found
}

const userId = getUserIdFromLocalStorage(); // Get user_id from local storage

async function loadUserProfile() {
    const userId = getUserIdFromLocalStorage(); // Extract the user_id from local storage
    if (!userId) {
        profileInfoContainer.innerHTML = '<p>Profile not found. Please log in.</p>';
        return;
    }

    try {
        const response = await fetch('https://campusarchive.com.ng/api/logged_user_profile.php', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${userId}`  // Send user_id in Authorization header
            }
        });
        const data = await response.json();
        if (data.profile) {
            renderProfileInfo(data.profile);
        } else {
            profileInfoContainer.innerHTML = '<p>Profile not found. Please log in.</p>';
        }
    } catch (error) {
        console.error('Error loading user profile:', error);
    }
}

function renderProfileInfo(profile) {
    const joinedDate = new Date(profile.date).toLocaleString('default', { month: 'long', year: 'numeric' });
    profileInfoContainer.innerHTML = `
        <img src="https://campusarchive.com.ng/image/${profile.img}" alt="Profile" class="pimg" id="profile-picture">
        <h1>${profile.name}</h1>
        <p class="username">@${profile.name}</p>
        <p class="additional-info">Joined ${joinedDate}</p>
    `;
}

function loadUserPosts() {
    const userId = getUserIdFromLocalStorage(); // Extract the user_id from local storage
    if (!userId) {
        postsContainer.innerHTML = '<p>Posts not found. Please log in.</p>';
        return;
    }

    loading = true;
    document.querySelector('.loading').style.display = 'block';

    fetch(`https://campusarchive.com.ng/api/logged_user_profile.php?page=${currentPage}&limit=${postsPerPage}`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${userId}`  // Send user_id in Authorization header
        }
    })
    .then(response => response.json())
      .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
        if (data.posts && data.posts.length > 0) {
            data.posts.forEach(post => {
                postsContainer.innerHTML += renderPost(post);
            });
            currentPage++;  // Increment page for pagination
            loading = false;
        }
        document.querySelector('.loading').style.display = 'none';
    })
    .catch(error => {
        console.error('Error fetching posts:', error);
        document.querySelector('.loading').style.display = 'none';
    });
}

function renderPost(post) {
    return `
        <div class="box" id="post-${post.id}">
            <div class="post-admin">
                <img src="https://campusarchive.com.ng/${post.adminImage}" alt="Admin Image" class="pimg" loading="lazy">
                <div>
                    <span class="profile-link">${post.adminName}</span>
                    <div class="dat">${timeAgo(post.date)}</div>
                </div>
            </div>
            <a href="view_post.html?post_id=${post.id}" class="inline-btn" id="co">
                <div class="post-content" id="pco">${post.content}</div>
                ${post.image && post.image !== 'null.jpg' ? 
                    `<img src="https://campusarchive.com.ng/uploaded_img/${post.image}" class="post-image" alt="" width="100%" height="auto" style="display: block; margin: 0 auto;">
                    <br>` : ''
                }
            </a>
            <div class="icons" id="icoo">
                <div onclick="confirmDelete(${post.id})"><i class="fas fa-trash"></i></div>
                <div><i class="fas fa-comment"></i><span>${post.comments}</span></div>
                <div onclick="copyUrl('${post.id}')"><i class="fas fa-share"></i></div>
                <button type="button" class="like-btn ${post.userLiked ? 'liked' : ''}" onclick="handleLike(${post.id}, this)">
                    <i class="fas fa-heart" style="${post.userLiked ? 'color:var(--red);' : 'color:grey;'}"></i>
                    <span>${post.likes}</span>
                </button>
            </div>
        </div>
    `;
}

function confirmDelete(postId) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            deletePost(postId);
            Swal.fire(
                'Deleted!',
                'Your post has been deleted.',
                'success'
            );
        }
    });
}

async function deletePost(postId) {
    try {
        const response = await fetch(`https://campusarchive.com.ng/api/logged_user_profile.php?post_id=${postId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${userId}`  // Send user_id in Authorization header
            }
        });
        const data = await response.json();
        if (data.success) {
            document.getElementById(`post-${postId}`).remove();
        } else {
            Swal.fire('Error', 'Failed to delete the post. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Error deleting post:', error);
    }
}

function timeAgo(dateString) {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);
    const intervals = {
        year: 31536000,
        month: 2592000,
        week: 604800,
        day: 86400,
        hour: 3600,
        minute: 60,
    };
    for (const [unit, value] of Object.entries(intervals)) {
        const interval = Math.floor(seconds / value);
        if (interval > 1) {
            return `${interval} ${unit}s ago`;
        }
    }
    return 'Just now';
}

It shows -3600 seconds 

window.addEventListener('scroll', function() {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 800) {
        if (!loading) {
            loadUserPosts();
        }
    }
});
