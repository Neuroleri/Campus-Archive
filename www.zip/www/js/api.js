// Get user ID from localStorage
function getUserIdFromLocalStorage() {
    return localStorage.getItem('user_id');
}
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('Service Worker Registered'))
        .catch((error) => console.error('Service Worker Registration Failed:', error));
}
// API call to check user session and get profile data
async function loadUserProfile() {
    try {
        const userId = getUserIdFromLocalStorage(); // Get user_id from localStorage
        const url = new URL('https://campusarchive.com.ng/api/getUserProfile.php');
        url.searchParams.append('user_id', userId); // Send user_id as query param

        const response = await fetch(url);
        const data = await response.json();

        if (data.user_id) {
            // User is logged in, set user info dynamically
            document.getElementById('user-btn').style.display = 'block';
            document.querySelector('.navbar').innerHTML += `<span>Welcome, ${data.name}</span>`;
        } else {
            // Redirect to login page if not logged in
            window.location.href = 'login.html';
        }
    } catch (error) {
        console.error('Error loading user profile:', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadUserProfile();
});

// Initialize variables for infinite scroll
let currentPage = 1;
let loading = false;
const postsPerPage = 10; // Number of posts per request
const postsContainer = document.getElementById('posts-box-container');

// Load posts when the page is loaded
document.addEventListener('DOMContentLoaded', function() {
    loadMorePosts();
});

// Infinite scroll logic
window.addEventListener('scroll', function() {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 800) {
        if (!loading) {
            if (!navigator.onLine) {
    
       return;  // Do not load if offline
                                    }

            else {
            loadMorePosts();
        }
    }
    } });
    
// Use IndexedDB to cache posts
function openDatabase() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('postsDB', 1);
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            db.createObjectStore('posts', { keyPath: 'id' });
        };
        request.onsuccess = (event) => {
            resolve(event.target.result);
        };
        request.onerror = (event) => {
            reject('Error opening IndexedDB:', event.target.error);
        };
    });
}

async function cachePosts(posts) {
    const db = await openDatabase();
    const transaction = db.transaction('posts', 'readwrite');
    const store = transaction.objectStore('posts');
    posts.forEach((post) => {

        store.put(post);
    });
}

async function getCachedPosts() {
    const db = await openDatabase();
    const transaction = db.transaction('posts', 'readonly');
    const store = transaction.objectStore('posts');
    return new Promise((resolve, reject) => {
        document.getElementById('spinner').style.display = 'none';
        const request = store.getAll();
        request.onsuccess = () => {
            resolve(request.result);
        };
        request.onerror = (event) => {
            reject('Error fetching posts from IndexedDB:', event.target.error);
        };
    });
}
function loadMorePosts() {
    if (loading) return; // Prevent multiple calls
    loading = true;
    document.querySelector('.loading').style.display = 'block';

    if (!navigator.onLine) {

        // If offline, load cached posts
        getCachedPosts().then((cachedPosts) => {
            if (cachedPosts && cachedPosts.length > 0) {
                cachedPosts.forEach((post) => {
                    postsContainer.innerHTML += renderPost(post);
                });
            }
            document.getElementById('spinner').style.display = 'none';
            loading = false;
            document.querySelector('.loading').style.display = 'none';
        }).catch(error => {
            console.error('Error loading cached posts:', error);
            loading = false;
            document.querySelector('.loading').style.display = 'none';
        });
    } else {
        // Fetch from API when online
        const userId = getUserIdFromLocalStorage();
        const url = new URL(`https://campusarchive.com.ng/api/posts.php`);
        url.searchParams.append('page', currentPage);
        url.searchParams.append('limit', postsPerPage);
        if (userId) {
            url.searchParams.append('user_id', userId);
        }

        fetch(url)
            .then(response => response.json())
              .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
                if (data.posts.length > 0) {
                    data.posts.forEach(post => {
                        postsContainer.innerHTML += renderPost(post);
                    });
                    cachePosts(data.posts); // Cache the fetched posts
                    currentPage++;
                }
                loading = false;
                document.querySelector('.loading').style.display = 'none';
            })
            .catch(error => {
                console.error('Error fetching posts:', error);
                loading = false; // Ensure loading is reset
                document.querySelector('.loading').style.display = 'none';
            });
    }
}

// Render the post HTML
function renderPost(post) {
    return `
        <div class="box">
            <div class="post-admin">
                <img src="https://campusarchive.com.ng/${post.adminImage}" alt="Admin Image" class="pimg" loading="lazy">
                <div>
                    <span class="profile-link" onclick="navigateToProfile('${post.adminName}')">${post.adminName}</span>
                    <div class="dat">${timeAgo(post.date)}</div>
                </div>
            </div>
            <a href="view_post.html?post_id=${post.id}" class="inline-btn" id="co">
                <div class="post-content" id="pco">${post.content}</div>
                ${post.image && post.image !== 'null.jpg' ? 
                    `<img src="https://campusarchive.com.ng/uploaded_img/${post.image}" class="post-image" alt="" width="100%" height="auto" style="display: block; margin: 0 auto;">
                    <br>` : ''
                }
            </a>
            <div class="icons" id="icoo">
                <div><i class="fas fa-comment"></i><span>${post.comments}</span></div>
                <div onclick="copyUrl('${post.id}')"><i class="fas fa-share"></i></div>
                <div class="report-button" onclick="reportPost(${post.id})">
                    <i class="fas fa-flag"></i>
                </div>
                <button type="button" class="like-btn ${post.userLiked ? 'liked' : ''}" onclick="handleLike(${post.id}, this)">
                    <i class="fas fa-heart" style="${post.userLiked ? 'color:var(--red);' : 'color:grey;'}"></i>
                    <span>${post.likes}</span>
                </button>
            </div>
        </div>
    `;
}

function navigateToProfile(adminName) {
    window.location.href = `u.html?u=${encodeURIComponent(adminName)}`;
}

// Utility function for time ago
function timeAgo(dateString) {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);
    const intervals = {
        year: 31536000,
        month: 2592000,
        week: 604800,
        day: 86400,
        hour: 3600,
        minute: 60,
    };
    for (const [unit, value] of Object.entries(intervals)) {
        const interval = Math.floor(seconds / value);
        if (interval > 1) {
            return `${interval} ${unit}s ago`;
        }
    }
    return 'Just now';
}

It shows -3600 seconds 