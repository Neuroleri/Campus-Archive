let securityQuestion = '';

function submitStep1() {
    const email = document.getElementById('email').value;
    console.log('Submitting step 1...');
    fetch('https://campusarchive.com.ng/api/recovery.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ step: '1', email: email }),
    })
    .then(response => response.json())
      .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
        if (data.status === 'success') {
            document.getElementById('step1').style.display = 'none';
            document.getElementById('step2').style.display = 'block';
            securityQuestion = data.security_question;

            // Store email in a hidden input for step 2
            const emailStep2Input = document.createElement('input');
            emailStep2Input.type = 'hidden';
            emailStep2Input.id = 'emailStep2';
            emailStep2Input.value = email;
            document.getElementById('step2').appendChild(emailStep2Input);

            Swal.fire({
                title: 'Security Question',
                text: securityQuestion,
                icon: 'question',
                confirmButtonText: 'OK'
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message || 'Failed to send security question.',
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Network Error',
            text: 'Please try again later.',
        });
    });
}

function submitStep2() {
    const email = document.getElementById('emailStep2').value;
    const securityAnswer = document.getElementById('securityAnswer').value;
    const newPassword = document.getElementById('newPassword').value;

    if (!email || !securityAnswer || !newPassword) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Please fill in all fields.',
        });
        return;
    }

    console.log('Submitting step 2...');
    fetch('https://campusarchive.com.ng/api/recovery.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            step: '2', 
            email: email,
            security_answer: securityAnswer, 
            new_password: newPassword 
        }),
    })
    .then(response => response.json())
      .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
        if (data.status === 'success') {
            Swal.fire({
                title: 'Success',
                text: 'Password updated successfully!',
                icon: 'success',
            });

            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1300);
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message || 'Incorrect security answer or new password.',
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Network Error',
            text: 'Please try again later.',
        });
    });
}