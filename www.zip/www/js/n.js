function getUserIdFromCookie() {
    const userIdString = localStorage.getItem('user_id'); // Fetch user_id from localStorage
    return userIdString ? Number(userIdString) : null;
}


        const userId = getUserIdFromCookie();
        const baseUrl = 'https://campusarchive.com.ng/api'; // Replace with your API URL

        // Format time difference
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const now = new Date();
            const diffInSeconds = Math.floor((now - date) / 1000);

            if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
            if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
            if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
            return `${Math.floor(diffInSeconds / 86400)}d ago`;
        }

        // Get notification message based on type
        function getNotificationMessage(notification) {
            switch(notification.type) {
                case 'like':
                    return `${notification.sender_name} liked your post`;
                case 'comment':
                    return `${notification.sender_name} commented on your post`;
                case 'reply':
                    return `${notification.sender_name} replied to your comment`;
                default:
                    return 'You have a new notification';
            }
        }

        // Fetch notifications
        async function fetchNotifications() {
    try {
        const response = await fetch(`${baseUrl}/get_notifications.php`, {
            
            headers: {
                'Authorization': `Bearer ${userId}`
            }
        });
        const data = await response.json();
                // Once API data is successfully loaded, hide the spinner
                document.getElementById('spinner').style.display = 'none';
        console.log('Received data:', data); // Add this line to debug
        
        // Ensure data is an array
        const notifications = Array.isArray(data) ? data : [];
        displayNotifications(notifications);
        updateNotificationBadge(notifications.filter(n => !n.is_read).length);
    } catch (error) {
        console.error('Error fetching notifications:', error);
    }
}

// And update the displayNotifications function to handle non-array data
function displayNotifications(notifications) {
    const container = document.getElementById('notificationsList');
    
    if (!Array.isArray(notifications) || notifications.length === 0) {
        container.innerHTML = '<div class="no-notifications">No notifications yet</div>';
        return;
    }

    container.innerHTML = notifications.map(notification => `
        <div class="notification-item ${!notification.is_read ? 'unread' : ''}" 
             onclick="handleNotificationClick('${notification.id}', '${notification.post_id}')">
            <img src="https://campusarchive.com.ng/image/${notification.sender_image || 'default-avatar.png'}" 
                 alt="" 
                 class="notification-avatar">
            <div class="notification-content">
                <p class="notification-title">${getNotificationMessage(notification)}</p>
                <p class="notification-time">${timeAgo(notification.created_at)}</p>
            </div>
        </div>
    `).join('');
}

        // Display notifications
        function displayNotifications(notifications) {
            const container = document.getElementById('notificationsList');
            
            if (notifications.length === 0) {
                container.innerHTML = '<div class="no-notifications">No notifications yet</div>';
                return;
            }

            container.innerHTML = notifications.map(notification => `
                <div class="notification-item ${!notification.is_read ? 'unread' : ''}" 
                     onclick="handleNotificationClick('${notification.id}', '${notification.post_id}')">
                    <img src="https://campusarchive.com.ng/image/${notification.sender_image || 'default-avatar.png'}" 
                         alt="" 
                         class="notification-avatar">
                    <div class="notification-content">
                        <p class="notification-title">${getNotificationMessage(notification)}</p>
                        <p class="notification-time">${timeAgo(notification.created_at)}</p>
                    </div>
                </div>
            `).join('');
        }

        // Update notification badge
        function updateNotificationBadge(count) {
            const badge = document.getElementById('notificationBadge');
            badge.textContent = count;
            badge.style.display = count > 0 ? 'block' : 'none';
        }

        // Handle notification click
        async function handleNotificationClick(notificationId, postId) {
            try {
                // Mark notification as read
                await fetch(`${baseUrl}/mark_notification_read.php`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${userId}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ notification_id: notificationId })
                });

                // Redirect to post
                window.location.href = `view_post.html?post_id=${postId}`;
            } catch (error) {
                console.error('Error marking notification as read:', error);
            }
        }

        // Fetch notifications initially
        fetchNotifications();

        // Poll for new notifications every 30 seconds
        setInterval(fetchNotifications, 30000);
    