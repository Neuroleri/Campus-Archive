
let navbar = document.querySelector('.header .flex .navbar');

document.querySelector('#menu-btn').onclick = () =>{
   navbar.classList.toggle('active');
   searchForm.classList.remove('active');
   profile.classList.remove('active');
}

let profile = document.querySelector('.header .flex .profile');


let searchForm = document.querySelector('.header .flex .search-form');
document.querySelector('#search-btn').onclick = () => {
   searchForm.classList.toggle('active');
   if (navbar) navbar.classList.remove('active');
   if (profile) profile.classList.remove('active');
}


window.onscroll = () =>{
   profile.classList.remove('active');
   navbar.classList.remove('active');
   searchForm.classList.remove('active');
}



document.addEventListener("DOMContentLoaded", function() {
    // Scroll to top button functionality
    const scrollToTopBtn = document.getElementById("scrollToTop");
    if (scrollToTopBtn) {
        window.addEventListener("scroll", function() {
            scrollToTopBtn.style.display =
            window.scrollY > 200 ? "block" :
            "block";
        });

        scrollToTopBtn.addEventListener("click", function() {
            window.scrollTo({ top: 0, behavior: "smooth" });
            setTimeout(function() {
                location.reload();
            }, 500);
        });
    }

    // Handle URL parameters for scrolling
    const urlParams = new URLSearchParams(window.location.search);
    const scrollToComment = urlParams.get('scroll_to_comment');
    const scrollToReply = urlParams.get('scroll_to_reply');
    const scrollTo = urlParams.get('scroll_to');

    if (scrollTo === 'comment_form') {
        const commentForm = document.getElementById('comment-form');
        if (commentForm) {
            commentForm.scrollIntoView({ behavior: 'smooth' });
        }
    }

});


function copyUrl(postId) {
    const url = `https://campusarchive.com.ng/view.html?post_id=${postId}`;
    const title = 'Check out this post';
    const text = `I found an interesting post on Campus Archive! ${url}`;

    // Fallback for devices without Web Share API
    if (isMobile()) {
        fallbackCopyToClipboard(url);
    } else {
        fallbackCopyToClipboard(url);
    }
}

// Check if the device is mobile
function isMobile() {
    return /Mobi|Android/i.test(navigator.userAgent);
}



// Fallback function for copying URL to clipboard with SweetAlert
function fallbackCopyToClipboard(url) {
    const tempInput = document.createElement('input');
    tempInput.value = url;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);

    // Show SweetAlert after copying
    Swal.fire({
        icon: 'success',
        title: 'Link copied!',
     
        confirmButtonText: 'OK'
    });
}


document.addEventListener('DOMContentLoaded', function () {
    const toggleButton = document.getElementById('theme-toggle');
    const body = document.body;

    // Load theme from localStorage
    const storedTheme = localStorage.getItem('theme');
    if (storedTheme) {
        if (storedTheme === 'dark' && !body.classList.contains('dark-mode')) {
            body.classList.add('dark-mode');
        } else if (storedTheme === 'light' && body.classList.contains('dark-mode')) {
            body.classList.remove('dark-mode');
        }
    }

    // Toggle theme on button click
    toggleButton.addEventListener('click', function () {
        body.classList.toggle('dark-mode');
        
        // Save user preference in localStorage
        if (body.classList.contains('dark-mode')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    });
});



// Function to toggle the like button UI
function toggleLikeUI(button, isLiked) {
    const icon = button.querySelector('i');
    const likeCount = button.querySelector('span');
    let currentCount = parseInt(likeCount.textContent);

    if (isLiked) {
        button.classList.add('liked');
        icon.style.color = 'var(--red)';
        likeCount.textContent = currentCount + 1;
    } else {
        button.classList.remove('liked');
        icon.style.color = 'grey';
        likeCount.textContent = Math.max(0, currentCount - 1);
    }
}


function getUserIdFromLocalStorage() {
    return localStorage.getItem('user_id');
}
function getUserIdFromCookie() {
    return localStorage.getItem('user_id');
}

// Function to handle like/unlike action
function handleLike(postId, button) {
    const userId = getUserIdFromCookie();
    if (!userId) {
        console.error('User ID not found in cookie');
        return;
    }

    const isLiked = button.classList.contains('liked');
    
    // Optimistically update UI
    toggleLikeUI(button, !isLiked);

    // Prepare the request data
    const data = new URLSearchParams();
    data.append(isLiked ? 'unlike_post' : 'like_post', 'true');
    data.append('post_id', postId);
    data.append('admin_id', userId);  // admin_id should be the logged-in user's ID

    // Send the request to the backend API
    fetch('https://campusarchive.com.ng/api/like_post.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Bearer ${userId}`,
        },
        body: data.toString(),
    })
    .then(response => response.json())
    .then(result => {
        if (result.status !== 'success') {
            // If the server request fails, revert the UI changes
            toggleLikeUI(button, isLiked);
        }
    })
    .catch(error => {
        console.error('Fetch request failed:', error);
        // Revert UI changes if the request fails
        toggleLikeUI(button, isLiked);
    });
}


        

// Function to handle the report submission
async function reportPost(postId) {
    const userId = getUserIdFromCookie();
    
    if (!userId) {
        Swal.fire({
            title: 'Authentication Required',
            text: 'You must be logged in to report a post.',
            icon: 'warning',
            confirmButtonColor: '#3085d6'
        });
        return;
    }

    try {
        const willReport = await Swal.fire({
            title: 'Report Post',
            text: 'Are you sure you want to report this post?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, report it',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33'
        });

        if (willReport.isConfirmed) {
            const response = await fetch('https://campusarchive.com.ng/api/report_post.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    content: postId,
                    name: userId
                })
            });

            const result = await response.json();

            if (result.message === 'Success') {
                await Swal.fire({
                    title: 'Success!',
                    text: 'Post has been reported',
                    icon: 'success',
                    confirmButtonColor: '#3085d6'
                });
            } else {
                throw new Error(result.message || 'Failed to report post');
            }
        }
    } catch (error) {
        console.error('Error reporting post:', error);
        await Swal.fire({
            title: 'Error',
            text: 'An error occurred while reporting the post. Please try again.',
            icon: 'error',
            confirmButtonColor: '#3085d6'
        });
    }
}



    document.getElementById('logout-btn').addEventListener('click', function () {
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, logout',
        cancelButtonText: 'No, stay logged in',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33'
    }).then(async (result) => {
        if (result.isConfirmed) {
            // Remove the userId from localStorage
            localStorage.removeItem('user_id'); // Adjust to match your localStorage key

            // Show success message
            await Swal.fire({
                title: 'Logged Out!',
                text: 'You have been successfully logged out.',
                icon: 'success',
                timer: 1500,
                showConfirmButton: false
            });

            // Redirect to the login page
            window.location.href = 'login.html';
        }
    });
});


function handleSearch(event) {
    event.preventDefault();
    const searchQuery = event.target.querySelector('input[name="search_box"]').value.trim();
    if (searchQuery) {
        window.location.href = `search.html?q=${encodeURIComponent(searchQuery)}`;
    }
}

window.addEventListener('load', function() {
    Capacitor.Plugins.App.addListener('backButton', () => {
        if (window.history.length > 1) {
            window.history.back();
        } else {
            Capacitor.Plugins.App.exitApp();
        }
    });
});


